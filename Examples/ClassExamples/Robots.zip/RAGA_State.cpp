#include <iostream>
using namespace std;

class State;

class Context {
public:
	Context();
	  ~Context();
	  void change();
	  string getColor();
	  void setState(State* state);
  protected:
    Context(State* state_);
	  State* getState();
  private: 
    State* state;
};

class RAGA_Context : public Context {
public:
  RAGA_Context();
  bool changer();
private:
  bool raga;
};

class State {
  public:
    virtual void handleChange(Context* c) = 0;
    virtual string getColor() = 0;
    virtual ~State();
};

State::~State(){
}

class RedState : public State {
  public:
    virtual void handleChange(Context* c);
    virtual string getColor();
};

class GreenState : public State {
  public:
    virtual void handleChange(Context* c);
    virtual string getColor();
};

class AmberState : public State {
  public:
    virtual void handleChange(Context* c);
    virtual string getColor();
};

class RAGA_AmberState : public AmberState {
public:
  virtual void handleChange(Context* c);
};

class RAGA_GreenState : public GreenState {
public:
  virtual void handleChange(Context* c);
};

class RAGA_RedState : public RedState {
public:
  virtual void handleChange(Context* c);
};

Context::Context() {
    this->state = new RedState();
}

Context::~Context() {
    delete this->state;
}

Context::Context(State* state_) {
    this->state = state_;
}


State* Context::getState() {
    return state;
}

void Context::setState(State* state) {
    delete this->state;
    this->state = state;
}

void Context::change() {
    state->handleChange(this);
}

string Context::getColor() {
    return state->getColor();
}

RAGA_Context::RAGA_Context() : Context() {
  setState(new RAGA_RedState());
  raga = true;
}

bool RAGA_Context::changer() {
  raga = !raga;
  return raga;
}

void RedState::handleChange(Context* c) {
    c->setState(new GreenState());
}

string RedState::getColor() {
    return "Red";
}

void RAGA_RedState::handleChange(Context* c) {
  c->setState(new RAGA_AmberState());
}

void AmberState::handleChange(Context* c) {
    c->setState(new RedState());
}

string AmberState::getColor() {
    return "Amber";
}

void RAGA_AmberState::handleChange(Context* c) {
  RAGA_Context* RAGA_c = static_cast<RAGA_Context*>(c);  // Note the cast
  if (RAGA_c->changer())
    c->setState(new RAGA_RedState());
  else
    c->setState(new RAGA_GreenState());
}

void GreenState::handleChange(Context* c) {
  c->setState(new AmberState());
}

string GreenState::getColor() {
    return "Green";
}

void RAGA_GreenState::handleChange(Context* c) {
  c->setState(new RAGA_AmberState());
}


int main(){
    Context* context = new RAGA_Context();
    for (int i = 0; i < 10; i++) {
        cout << "Traffic light is currently: " << context->getColor() << endl;
        context->change();
    }
    delete context;
    return 0; 
}
