//
// Created by jo on 2020/09/01.
//

#include "UseHandSanitiser.h"


/*
UseHandSanitiser::UseHandSanitiser() {
    readFile("/home/jo/CLionProjects/Software-Modelling/Assignments/A2/sanitiser.txt");
}

void UseHandSanitiser::drawPoster() {
    //cout << termcolor::reset << termcolor::cyan ;
    for (string l: lines) {
        addLine(l);
    }
    ImageAddOns::drawPoster();
}

UseHandSanitiser::~UseHandSanitiser() {}
*/
