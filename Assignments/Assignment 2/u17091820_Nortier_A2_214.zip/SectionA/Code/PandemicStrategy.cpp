//
// Created by jo on 2020/08/26.
//

#include "PandemicStrategy.h"

PandemicStrategy::PandemicStrategy() {
    //cout << "Constructor: PandemicStrategy" << endl;

}

PandemicStrategy::~PandemicStrategy() {
    //cout << "Destructor: PandemicStrategy" << endl;
}
