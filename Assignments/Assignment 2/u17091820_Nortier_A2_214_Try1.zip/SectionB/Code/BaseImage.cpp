//
// Created by jo on 2020/09/01.
//

#include "BaseImage.h"

/*
void BaseImage::drawPoster() {
//header
    cout << termcolor::reset << termcolor::crossed;
    for (int i = 0; i < width; ++i) {
        cout << borderPixel;
    }
    cout << termcolor::reset << endl;
//inner
    for (Poster* p: imageHeight) {
        //cout << "drawing an image" << endl;
        p->drawPoster();
    }
//footer
    cout << termcolor::reset << termcolor::crossed;
    for (int i = 0; i < width; ++i) {
        cout << borderPixel;
    }
    cout << endl;

}

void BaseImage::addImage(Poster *i) {
    if (imageHeight.size() < getHeight()) {
        imageHeight.push_back( i);
    }
    else {
        cout << "Full. Can't add more to poster" << endl;
    }
}

BaseImage::BaseImage() {
    int h = 5;
    setHeight(h);
    imageHeight.reserve(getHeight());
}

void BaseImage::addLine(string line) {}
*/
