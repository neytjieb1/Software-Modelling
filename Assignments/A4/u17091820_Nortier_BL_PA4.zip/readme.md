###Practical Assignment 4

#### Instructions

Find inside a folder named Code, this readme and a .jpeg file with the associated activity diagram for Task 6.

To run the code, enter the folder Code and use the makefile inside to make and make run. 

My main consists of three helper functions, each one separately demonstrating a single design pattern. 
For best use, I would recommend running only one function at a time and keeping the other two commented out.  