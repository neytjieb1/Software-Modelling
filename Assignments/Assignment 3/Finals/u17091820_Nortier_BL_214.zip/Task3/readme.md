###Task 3

Find attached a folder containing my code as well as a makefile which can be used to compile and run the code using the commands:
        
        make
        make run
    
I created two helper functions traverseStruct and setVerbose which aided me in testing. 

traverseStruct has a default parameter of true which indicates whether or not the current structure is traversed from the start.

setVerbose allows for more/less detailed printing


I made a small change somewhere right before uploading and can't seem to remove a small problem with regards to implementation. 
This was solved rather inelegantly by putting all class-definitions together.

   
