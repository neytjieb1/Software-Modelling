###Task 4

Find attached a folder containing my code as well as a makefile which can be used to compile and run the code using the commands:
        
        make
        make run
    
Before running, it is important to change the file path in the main file so as to facilitate the testing system by removing the manual input every time.

   