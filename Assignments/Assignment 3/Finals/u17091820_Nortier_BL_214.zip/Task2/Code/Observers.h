//
// Created by jo on 2020/09/14.
//

#ifndef A3_OBSERVERS_H
#define A3_OBSERVERS_H


class Observers {
private:

public:
    virtual void update() = 0;


};


#endif //A3_OBSERVERS_H
