#include <iostream>
#include "Prisoner.h"
#include "BorderGuard.h"
#include "PrisonArea.h"

int main() {
    PrisonArea *prisonArea = new PrisonArea(10, 6);
    //prisonArea->print();

    cout << "RIGHT RIGHT RIGHT RIGHT" << endl;
    for (int i = 0; i < 4; ++i) {
        prisonArea->getPrisoner()->runTowards(Right);
    }
    //prisonArea->print();

    cout << "RIGHT" << endl;
    prisonArea->getPrisoner()->runTowards(Right);
    prisonArea->print();

    cout << "\n\nUP AND LEFT" << endl;
    for (int i = 0; i < 3; ++i) {
        prisonArea->getPrisoner()->runTowards(Up);
        prisonArea->getPrisoner()->runTowards(Left);
        prisonArea->getPrisoner()->runTowards(Left);
    }
    prisonArea->print();

    cout << "UP" << endl;
    prisonArea->getPrisoner()->runTowards(Up);
    prisonArea->print();


    delete prisonArea;

    return 0;

}
