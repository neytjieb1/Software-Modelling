###Task 4

Find attached a folder containing my code as well as a makefile which can be used to compile and run the code using the commands:
        
        make
        make run
    
I made a small change somewhere right before uploading and can't seem to remove a small problem with regards to implementation. 
This was solved rather inelegantly by putting all class-definitions together.

   